package com.sstar.executor;

public class TransferRequest {
    private String id;
    private String phone;
    private String amount;
    private String company;
    private String ussdCode;
    private long timestamp;
    private String status;
    private String message;
    private String selectedOffer;
    private String screenshotPath;

    public TransferRequest() {
        this.id = String.valueOf(System.currentTimeMillis());
        this.timestamp = System.currentTimeMillis();
        this.status = "PENDING";
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getAmount() { return amount; }
    public void setAmount(String amount) { this.amount = amount; }

    public String getCompany() { return company; }
    public void setCompany(String company) { this.company = company; }

    public String getUssdCode() { return ussdCode; }
    public void setUssdCode(String ussdCode) { this.ussdCode = ussdCode; }

    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public String getSelectedOffer() { return selectedOffer; }
    public void setSelectedOffer(String selectedOffer) { this.selectedOffer = selectedOffer; }

    public String getScreenshotPath() { return screenshotPath; }
    public void setScreenshotPath(String screenshotPath) { this.screenshotPath = screenshotPath; }
}
