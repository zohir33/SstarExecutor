package com.sstar.executor;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class FriendActivity extends AppCompatActivity {

    private Spinner companySpinner;
    private EditText phoneInput, amountInput;
    private TextView previewText, ussdPreviewText, statusText;
    private Button executeButton, backButton;
    private LinearLayout inputLayout, captureLayout, choiceLayout, confirmLayout;
    private ImageView captureImageView;
    private Button[] choiceButtons;
    private Button confirmButton, cancelButton;

    private CompanyConfig selectedCompany;
    private List<CompanyConfig> companies;
    private TransferRequest currentRequest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friend);

        initViews();
        loadCompanies();
        setupListeners();

        // Check if coming from screen capture
        handleIntent(getIntent());

        checkAccessibilityService();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    private void initViews() {
        companySpinner = findViewById(R.id.friend_company_spinner);
        phoneInput = findViewById(R.id.friend_phone_input);
        amountInput = findViewById(R.id.friend_amount_input);
        previewText = findViewById(R.id.friend_preview_text);
        ussdPreviewText = findViewById(R.id.friend_ussd_preview);
        statusText = findViewById(R.id.friend_status_text);
        executeButton = findViewById(R.id.friend_execute_button);
        backButton = findViewById(R.id.friend_back_button);

        inputLayout = findViewById(R.id.friend_input_layout);
        captureLayout = findViewById(R.id.friend_capture_layout);
        choiceLayout = findViewById(R.id.friend_choice_layout);
        confirmLayout = findViewById(R.id.friend_confirm_layout);
        captureImageView = findViewById(R.id.friend_capture_image);

        // Choice buttons 1-9
        choiceButtons = new Button[9];
        for (int i = 0; i < 9; i++) {
            int resId = getResources().getIdentifier("choice_" + (i + 1), "id", getPackageName());
            if (resId != 0) {
                choiceButtons[i] = findViewById(resId);
                final int choice = i + 1;
                choiceButtons[i].setOnClickListener(v -> selectOffer(String.valueOf(choice)));
            }
        }

        confirmButton = findViewById(R.id.friend_confirm_button);
        cancelButton = findViewById(R.id.friend_cancel_button);

        confirmButton.setOnClickListener(v -> confirmTransfer());
        cancelButton.setOnClickListener(v -> resetToInput());

        amountInput.setText(String.valueOf(SstarApplication.getInstance().getDefaultAmount()));
        setTitle("Friend Mode - Send Transfer");
    }

    private void loadCompanies() {
        companies = SstarApplication.getInstance().getCompanyConfigs();
        List<String> names = new ArrayList<>();
        for (CompanyConfig c : companies) {
            names.add(c.getName());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, 
            android.R.layout.simple_spinner_item, names);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        companySpinner.setAdapter(adapter);

        companySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedCompany = companies.get(position);
                updatePreview();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        if (!companies.isEmpty()) {
            selectedCompany = companies.get(0);
        }
    }

    private void setupListeners() {
        phoneInput.addTextChangedListener(new SimpleTextWatcher() {
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                updatePreview();
            }
        });
        amountInput.addTextChangedListener(new SimpleTextWatcher() {
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                updatePreview();
            }
        });

        executeButton.setOnClickListener(v -> executeTransfer());
        backButton.setOnClickListener(v -> finish());
    }

    private void updatePreview() {
        if (selectedCompany == null) return;

        String phone = phoneInput.getText().toString().trim();
        String amount = amountInput.getText().toString().trim();

        if (phone.isEmpty()) {
            previewText.setText("Enter phone number");
            ussdPreviewText.setText("");
            return;
        }
        if (amount.isEmpty()) {
            previewText.setText("Enter amount");
            ussdPreviewText.setText("");
            return;
        }

        String ussd = selectedCompany.buildUssd(phone, amount);
        previewText.setText("Company: " + selectedCompany.getName());
        ussdPreviewText.setText("USSD: " + ussd);
    }

    private void executeTransfer() {
        if (selectedCompany == null) {
            Toast.makeText(this, "Please select a company", Toast.LENGTH_SHORT).show();
            return;
        }

        String phone = phoneInput.getText().toString().trim();
        String amount = amountInput.getText().toString().trim();

        if (phone.isEmpty()) {
            phoneInput.setError("Phone number required");
            return;
        }
        if (amount.isEmpty()) {
            amountInput.setError("Amount required");
            return;
        }

        if (!isValidAlgerianPhone(phone)) {
            new AlertDialog.Builder(this)
                .setTitle("Invalid Phone Number")
                .setMessage("Please enter a valid Algerian phone number\n(05, 06, or 07 followed by 8 digits)")
                .setPositiveButton("OK", null)
                .show();
            return;
        }

        String ussd = selectedCompany.buildUssd(phone, amount);

        currentRequest = new TransferRequest();
        currentRequest.setPhone(phone);
        currentRequest.setAmount(amount);
        currentRequest.setCompany(selectedCompany.getName());
        currentRequest.setUssdCode(ussd);
        currentRequest.setStatus("EXECUTING");
        SstarApplication.getInstance().addTransferHistory(currentRequest);

        // Start execution service with friend mode
        Intent intent = new Intent(this, ExecutionService.class);
        intent.putExtra("ussd", ussd);
        intent.putExtra("auto_confirm", false); // Friend mode - wait for selection
        intent.putExtra("request_id", currentRequest.getId());
        intent.putExtra("friend_mode", true);
        startService(intent);

        // Show waiting state
        showWaitingState();
    }

    private void showWaitingState() {
        inputLayout.setVisibility(View.GONE);
        captureLayout.setVisibility(View.VISIBLE);
        choiceLayout.setVisibility(View.GONE);
        confirmLayout.setVisibility(View.GONE);
        statusText.setText("Dialing USSD... Please wait");
        captureImageView.setImageResource(android.R.drawable.ic_menu_call);
    }

    private void handleIntent(Intent intent) {
        if (intent == null) return;

        if (intent.getBooleanExtra("show_capture", false)) {
            String path = intent.getStringExtra("capture_path");
            boolean waitingChoice = intent.getBooleanExtra("waiting_choice", false);
            boolean waitingConfirm = intent.getBooleanExtra("waiting_confirm", false);

            if (path != null) {
                showCapture(path, waitingChoice, waitingConfirm);
            }
        }
    }

    private void showCapture(String path, boolean waitingChoice, boolean waitingConfirm) {
        File file = new File(path);
        if (file.exists()) {
            Bitmap bitmap = BitmapFactory.decodeFile(path);
            captureImageView.setImageBitmap(bitmap);
        }

        inputLayout.setVisibility(View.GONE);
        captureLayout.setVisibility(View.VISIBLE);

        if (waitingChoice) {
            choiceLayout.setVisibility(View.VISIBLE);
            confirmLayout.setVisibility(View.GONE);
            statusText.setText("Select an offer from the screen:");
        } else if (waitingConfirm) {
            choiceLayout.setVisibility(View.GONE);
            confirmLayout.setVisibility(View.VISIBLE);
            statusText.setText("Confirm the transfer:");
        }
    }

    private void selectOffer(String choice) {
        statusText.setText("Selected: " + choice + " - Processing...");
        choiceLayout.setVisibility(View.GONE);

        // Send choice to ExecutionService
        Intent intent = new Intent(this, ExecutionService.class);
        intent.putExtra("select_offer", choice);
        startService(intent);

        if (currentRequest != null) {
            currentRequest.setSelectedOffer(choice);
        }
    }

    private void confirmTransfer() {
        statusText.setText("Confirming transfer...");
        confirmLayout.setVisibility(View.GONE);

        // Send confirm to ExecutionService
        Intent intent = new Intent(this, ExecutionService.class);
        intent.putExtra("confirm_transfer", true);
        startService(intent);

        if (currentRequest != null) {
            currentRequest.setStatus("SUCCESS");
        }

        // Reset after delay
        statusText.setText("Transfer completed successfully!");
        captureImageView.postDelayed(this::resetToInput, 3000);
    }

    private void resetToInput() {
        inputLayout.setVisibility(View.VISIBLE);
        captureLayout.setVisibility(View.GONE);
        choiceLayout.setVisibility(View.GONE);
        confirmLayout.setVisibility(View.GONE);
        statusText.setText("");
        phoneInput.setText("");
        amountInput.setText(String.valueOf(SstarApplication.getInstance().getDefaultAmount()));
        updatePreview();
    }

    private boolean isValidAlgerianPhone(String phone) {
        phone = phone.replaceAll("[\s-]", "");
        return phone.matches("^(05|06|07)[0-9]{8}$");
    }

    private void checkAccessibilityService() {
        if (!USSDService.isEnabled(this)) {
            new AlertDialog.Builder(this)
                .setTitle("Service Required")
                .setMessage("Accessibility service must be enabled for automatic execution.")
                .setPositiveButton("Enable", (dialog, which) -> {
                    Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
                    startActivity(intent);
                })
                .setNegativeButton("Cancel", (dialog, which) -> finish())
                .setCancelable(false)
                .show();
        }
    }
}
