package com.sstar.executor;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;

import androidx.core.app.NotificationCompat;

public class ExecutionService extends Service {

    private static final String TAG = "ExecutionService";
    private static final String CHANNEL_ID = "sstar_execution";
    private static final int NOTIFICATION_ID = 1;

    private Handler handler;
    private TransferRequest currentRequest;
    private int step = 0; // 0: dial, 1: capture offers, 2: wait choice, 3: confirm

    @Override
    public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;

        String ussd = intent.getStringExtra("ussd");
        boolean autoConfirm = intent.getBooleanExtra("auto_confirm", false);
        String requestId = intent.getStringExtra("request_id");
        boolean friendMode = intent.getBooleanExtra("friend_mode", false);

        if (ussd == null || ussd.isEmpty()) {
            stopSelf();
            return START_NOT_STICKY;
        }

        // Start as foreground service
        Notification notification = buildNotification("Starting execution...");
        startForeground(NOTIFICATION_ID, notification);

        // Execute USSD
        executeUssd(ussd, autoConfirm, requestId, friendMode);

        return START_NOT_STICKY;
    }

    private void executeUssd(String ussd, boolean autoConfirm, String requestId, boolean friendMode) {
        String encodedUssd = ussd.replace("#", "%23");

        // Step 1: Dial USSD
        step = 1;
        updateNotification("Dialing USSD...");

        Intent dialIntent = new Intent(Intent.ACTION_CALL);
        dialIntent.setData(Uri.parse("tel:" + encodedUssd));
        dialIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        USSDService ussdService = USSDService.getInstance();
        if (ussdService != null) {
            ussdService.setExecuting(true);
            ussdService.setAutoConfirm(autoConfirm);
        }

        int delay = SstarApplication.getInstance().getDelay() * 1000;

        handler.postDelayed(() -> {
            try {
                startActivity(dialIntent);
                Log.d(TAG, "Dialing: " + ussd);

                // Step 2: Wait for dialog and capture screen
                handler.postDelayed(() -> {
                    if (friendMode) {
                        captureAndShowOffers();
                    } else {
                        // Admin mode - auto confirm if enabled
                        if (autoConfirm && ussdService != null) {
                            ussdService.setPendingChoice("1");
                        }
                        stopSelf();
                    }
                }, 3000);

            } catch (Exception e) {
                Log.e(TAG, "Failed to dial: " + e.getMessage());
                updateNotification("Failed: " + e.getMessage());
                stopSelf();
            }
        }, delay);
    }

    private void captureAndShowOffers() {
        step = 2;
        updateNotification("Capturing offers screen...");

        ScreenCaptureActivity.startCapture(this, new ScreenCaptureActivity.CaptureCallback() {
            @Override
            public void onCaptureComplete(String path) {
                Log.d(TAG, "Screen captured: " + path);

                // Show the captured screen in FriendActivity
                Intent showIntent = new Intent(ExecutionService.this, FriendActivity.class);
                showIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                showIntent.putExtra("show_capture", true);
                showIntent.putExtra("capture_path", path);
                showIntent.putExtra("waiting_choice", true);
                startActivity(showIntent);

                updateNotification("Waiting for offer selection...");
            }

            @Override
            public void onCaptureFailed(String error) {
                Log.e(TAG, "Capture failed: " + error);
                updateNotification("Capture failed: " + error);
                stopSelf();
            }
        });
    }

    // Called from FriendActivity when user selects an offer
    public void selectOffer(String choice) {
        Log.d(TAG, "Offer selected: " + choice);

        step = 3;
        updateNotification("Selecting offer: " + choice);

        USSDService ussdService = USSDService.getInstance();
        if (ussdService != null) {
            ussdService.setPendingChoice(choice);
        }

        // Wait then capture confirmation screen
        handler.postDelayed(() -> {
            captureConfirmationScreen();
        }, 2000);
    }

    private void captureConfirmationScreen() {
        ScreenCaptureActivity.startCapture(this, new ScreenCaptureActivity.CaptureCallback() {
            @Override
            public void onCaptureComplete(String path) {
                // Show confirmation screen
                Intent showIntent = new Intent(ExecutionService.this, FriendActivity.class);
                showIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                showIntent.putExtra("show_capture", true);
                showIntent.putExtra("capture_path", path);
                showIntent.putExtra("waiting_confirm", true);
                startActivity(showIntent);

                updateNotification("Waiting for final confirmation...");
            }

            @Override
            public void onCaptureFailed(String error) {
                stopSelf();
            }
        });
    }

    // Called from FriendActivity for final confirmation
    public void confirmTransfer() {
        Log.d(TAG, "Transfer confirmed");

        USSDService ussdService = USSDService.getInstance();
        if (ussdService != null) {
            ussdService.setPendingChoice("1"); // Usually "1" for confirm
        }

        updateNotification("Transfer completed!");
        handler.postDelayed(this::stopSelf, 3000);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Sstar Execution",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Shows execution status");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    private Notification buildNotification(String text) {
        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
            this, 0, intent, PendingIntent.FLAG_IMMUTABLE
        );

        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Sstar Executor")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_call)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build();
    }

    private void updateNotification(String text) {
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) {
            manager.notify(NOTIFICATION_ID, buildNotification(text));
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
        USSDService ussdService = USSDService.getInstance();
        if (ussdService != null) {
            ussdService.setExecuting(false);
        }
    }
}
