package com.sstar.executor;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.WindowManager;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;

public class ScreenCaptureActivity extends Activity {

    private static final String TAG = "ScreenCapture";
    private static final int REQUEST_CODE = 100;
    private static MediaProjection mediaProjection;
    private static ImageReader imageReader;
    private static VirtualDisplay virtualDisplay;
    private static CaptureCallback callback;

    public interface CaptureCallback {
        void onCaptureComplete(String path);
        void onCaptureFailed(String error);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        MediaProjectionManager projectionManager = 
            (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);

        if (projectionManager != null) {
            startActivityForResult(
                projectionManager.createScreenCaptureIntent(), 
                REQUEST_CODE
            );
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK) {
            MediaProjectionManager projectionManager = 
                (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);

            if (projectionManager != null) {
                mediaProjection = projectionManager.getMediaProjection(resultCode, data);
                captureScreen();
            }
        } else {
            if (callback != null) {
                callback.onCaptureFailed("Permission denied");
            }
            finish();
        }
    }

    private void captureScreen() {
        DisplayMetrics metrics = new DisplayMetrics();
        WindowManager windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        windowManager.getDefaultDisplay().getMetrics(metrics);

        int width = metrics.widthPixels;
        int height = metrics.heightPixels;
        int density = metrics.densityDpi;

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);

        virtualDisplay = mediaProjection.createVirtualDisplay(
            "ScreenCapture",
            width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader.getSurface(), null, null
        );

        // Wait a bit for the frame
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            Image image = imageReader.acquireLatestImage();
            if (image != null) {
                saveImage(image, width, height);
                image.close();
            } else {
                if (callback != null) {
                    callback.onCaptureFailed("Failed to acquire image");
                }
            }
            cleanup();
            finish();
        }, 500);
    }

    private void saveImage(Image image, int width, int height) {
        Image.Plane[] planes = image.getPlanes();
        ByteBuffer buffer = planes[0].getBuffer();
        int pixelStride = planes[0].getPixelStride();
        int rowStride = planes[0].getRowStride();
        int rowPadding = rowStride - pixelStride * width;

        Bitmap bitmap = Bitmap.createBitmap(
            width + rowPadding / pixelStride, 
            height, 
            Bitmap.Config.ARGB_8888
        );
        bitmap.copyPixelsFromBuffer(buffer);

        // Crop to actual screen size
        Bitmap cropped = Bitmap.createBitmap(bitmap, 0, 0, width, height);
        bitmap.recycle();

        // Save to file
        String path = SstarApplication.getInstance().getCapturePath();
        try {
            File file = new File(path);
            file.getParentFile().mkdirs();
            FileOutputStream fos = new FileOutputStream(file);
            cropped.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.close();
            cropped.recycle();

            Log.d(TAG, "Screenshot saved: " + path);
            if (callback != null) {
                callback.onCaptureComplete(path);
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to save: " + e.getMessage());
            if (callback != null) {
                callback.onCaptureFailed(e.getMessage());
            }
        }
    }

    private void cleanup() {
        if (virtualDisplay != null) {
            virtualDisplay.release();
            virtualDisplay = null;
        }
        if (imageReader != null) {
            imageReader.close();
            imageReader = null;
        }
        if (mediaProjection != null) {
            mediaProjection.stop();
            mediaProjection = null;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        cleanup();
    }

    // Static method to start capture from anywhere
    public static void startCapture(Context context, CaptureCallback cb) {
        callback = cb;
        Intent intent = new Intent(context, ScreenCaptureActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }
}
