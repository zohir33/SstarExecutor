package com.sstar.executor;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;

public class USSDService extends AccessibilityService {

    private static final String TAG = "USSDService";
    private static USSDService instance;

    private boolean autoConfirm = false;
    private String pendingChoice = null;
    private boolean isExecuting = false;

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;

        AccessibilityServiceInfo info = new AccessibilityServiceInfo();
        info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED | 
                         AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED;
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.flags = AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS |
                    AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS;
        info.packageNames = new String[]{"com.android.phone", "com.google.android.dialer", 
                                         "com.samsung.android.dialer", "com.huawei.android.dialer"};
        setServiceInfo(info);

        Log.d(TAG, "USSD Service Connected");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            event.getEventType() == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {

            AccessibilityNodeInfo rootNode = getRootInActiveWindow();
            if (rootNode == null) return;

            // Check if this is a USSD dialog
            if (isUssdDialog(rootNode)) {
                handleUssdDialog(rootNode);
            }

            rootNode.recycle();
        }
    }

    @Override
    public void onInterrupt() {
        Log.d(TAG, "Service Interrupted");
    }

    private boolean isUssdDialog(AccessibilityNodeInfo rootNode) {
        // Check for common USSD dialog indicators
        String[] indicators = {"OK", "1", "2", "3", "4", "5", "Send", "Confirm", 
                              "Oui", "نعم", "موافق", "Cancel", "إلغاء"};

        for (String text : indicators) {
            List<AccessibilityNodeInfo> nodes = rootNode.findAccessibilityNodeInfosByText(text);
            if (!nodes.isEmpty()) {
                for (AccessibilityNodeInfo node : nodes) {
                    node.recycle();
                }
                return true;
            }
        }

        return false;
    }

    private void handleUssdDialog(AccessibilityNodeInfo rootNode) {
        Log.d(TAG, "USSD Dialog detected, isExecuting: " + isExecuting);

        // If we have a pending choice (from friend), click it
        if (pendingChoice != null) {
            Log.d(TAG, "Clicking pending choice: " + pendingChoice);
            clickButton(rootNode, pendingChoice);
            pendingChoice = null;
            return;
        }

        // If auto-confirm is enabled
        if (autoConfirm && isExecuting) {
            // Try to find confirmation button
            String[] confirmTexts = {"1", "OK", "Send", "Confirm", "Oui", "نعم", "موافق"};
            for (String text : confirmTexts) {
                if (clickButton(rootNode, text)) {
                    Log.d(TAG, "Auto-clicked: " + text);
                    return;
                }
            }
        }
    }

    private boolean clickButton(AccessibilityNodeInfo rootNode, String text) {
        List<AccessibilityNodeInfo> nodes = rootNode.findAccessibilityNodeInfosByText(text);
        if (!nodes.isEmpty()) {
            for (AccessibilityNodeInfo node : nodes) {
                if (node.isClickable()) {
                    node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                    Log.d(TAG, "Clicked: " + text);
                    node.recycle();
                    return true;
                }
                // Try parent if not clickable
                AccessibilityNodeInfo parent = node.getParent();
                if (parent != null && parent.isClickable()) {
                    parent.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                    Log.d(TAG, "Clicked parent of: " + text);
                    parent.recycle();
                    node.recycle();
                    return true;
                }
                node.recycle();
            }
        }
        return false;
    }

    // Called from ExecutionService to set pending choice
    public void setPendingChoice(String choice) {
        this.pendingChoice = choice;
        Log.d(TAG, "Pending choice set: " + choice);
    }

    public void setAutoConfirm(boolean auto) {
        this.autoConfirm = auto;
    }

    public void setExecuting(boolean executing) {
        this.isExecuting = executing;
    }

    public static USSDService getInstance() {
        return instance;
    }

    public static boolean isEnabled(Context context) {
        String enabledServices = Settings.Secure.getString(
            context.getContentResolver(),
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        );
        if (enabledServices == null) return false;

        String serviceName = context.getPackageName() + "/" + USSDService.class.getName();
        return enabledServices.contains(serviceName);
    }
}
