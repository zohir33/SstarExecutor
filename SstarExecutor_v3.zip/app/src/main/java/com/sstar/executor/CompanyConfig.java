package com.sstar.executor;

public class CompanyConfig {
    private String name;
    private String ussdTemplate;
    private String testNumber;

    public CompanyConfig() {}

    public CompanyConfig(String name, String ussdTemplate, String testNumber) {
        this.name = name;
        this.ussdTemplate = ussdTemplate;
        this.testNumber = testNumber;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getUssdTemplate() { return ussdTemplate; }
    public void setUssdTemplate(String ussdTemplate) { this.ussdTemplate = ussdTemplate; }

    public String getTestNumber() { return testNumber; }
    public void setTestNumber(String testNumber) { this.testNumber = testNumber; }

    public String buildUssd(String phone, String amount) {
        return ussdTemplate.replace("{phone}", phone).replace("{amount}", amount);
    }

    @Override
    public String toString() { return name; }
}
