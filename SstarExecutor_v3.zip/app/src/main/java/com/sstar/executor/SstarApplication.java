package com.sstar.executor;

import android.app.Application;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class SstarApplication extends Application {

    private static SstarApplication instance;
    private SharedPreferences prefs;
    private Gson gson;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        prefs = getSharedPreferences("sstar_prefs", MODE_PRIVATE);
        gson = new Gson();
    }

    public static SstarApplication getInstance() {
        return instance;
    }

    public void saveCompanyConfig(CompanyConfig config) {
        List<CompanyConfig> configs = getCompanyConfigs();
        boolean found = false;
        for (int i = 0; i < configs.size(); i++) {
            if (configs.get(i).getName().equals(config.getName())) {
                configs.set(i, config);
                found = true;
                break;
            }
        }
        if (!found) configs.add(config);
        prefs.edit().putString("companies", gson.toJson(configs)).apply();
    }

    public List<CompanyConfig> getCompanyConfigs() {
        String json = prefs.getString("companies", null);
        if (json == null) {
            List<CompanyConfig> defaults = new ArrayList<>();
            defaults.add(new CompanyConfig("Mobilis", "*222*{phone}*{amount}#", "0659698908"));
            defaults.add(new CompanyConfig("Djezzy", "*777*{phone}*{amount}#", "0770123456"));
            defaults.add(new CompanyConfig("Ooredoo", "*100*{phone}*{amount}#", "0560123456"));
            return defaults;
        }
        Type type = new TypeToken<List<CompanyConfig>>(){}.getType();
        return gson.fromJson(json, type);
    }

    public CompanyConfig getCompanyConfig(String name) {
        for (CompanyConfig c : getCompanyConfigs()) {
            if (c.getName().equals(name)) return c;
        }
        return null;
    }

    public void addTransferHistory(TransferRequest request) {
        List<TransferRequest> history = getTransferHistory();
        history.add(0, request);
        prefs.edit().putString("history", gson.toJson(history)).apply();
    }

    public List<TransferRequest> getTransferHistory() {
        String json = prefs.getString("history", null);
        if (json == null) return new ArrayList<>();
        Type type = new TypeToken<List<TransferRequest>>(){}.getType();
        return gson.fromJson(json, type);
    }

    public void setDefaultAmount(int amount) {
        prefs.edit().putInt("default_amount", amount).apply();
    }

    public int getDefaultAmount() {
        return prefs.getInt("default_amount", 1000);
    }

    public void setAutoConfirm(boolean auto) {
        prefs.edit().putBoolean("auto_confirm", auto).apply();
    }

    public boolean isAutoConfirm() {
        return prefs.getBoolean("auto_confirm", false);
    }

    public void setDelay(int seconds) {
        prefs.edit().putInt("delay_seconds", seconds).apply();
    }

    public int getDelay() {
        return prefs.getInt("delay_seconds", 3);
    }

    // Screen capture path
    public String getCapturePath() {
        return getExternalFilesDir(null) + "/capture.png";
    }
}
